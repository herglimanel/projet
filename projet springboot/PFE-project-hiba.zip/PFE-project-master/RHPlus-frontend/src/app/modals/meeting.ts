export class Meeting {
      idMeeting : number;
	  titre:String;
	  type:String;
	  meetingDay:Date;
	  meetingTime:Date;
	  canceled:boolean;
}