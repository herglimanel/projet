export class Employe { 
  
    public idUser:number;
    public prenom:string;
    public nom:string;
    public dateOfBirth:Date;
    public phone : string;
    public  email : String;
	public  cin : String;
	public  adresse : String;
	public  ville : String;
    public  photo : String;
    public  status : String;
    public  cnss : String;
    public  departement : String;
    public  fonction : String;
    public  typeContrat : String;
    public  dateEntree : Date;
    public joursConges :number;
    public  soldeConges :number;
    public  coutHeuresSup : String;
    public  dureeConges : String;
    public  salary : String;
    public username : String;
    public password : String;

}