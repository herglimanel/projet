export class User { 
  
    public idUser:number;
    public prenom:string;
    public nom:string;
    public dateOfBirth:Date;
    public phone : string;
    public  email : String;
	public  cin : String;
	public  adresse : String;
	public  ville : String;
    public  photo : String;
    public  status : String;
    public  cnss : String;
    public  departement : String;
    public  fonction : String;
    public  typeContrat : String;
    public  dateEntree : Date;
    public  coutHeuresSup : String;
    public  dureeConges : number;
    public  soldeConges :number;
    public joursConges :number;
    public  salary : String;
    public username : String;
    public password : String;
    public repassword : String;
    public budget : number;
    

}