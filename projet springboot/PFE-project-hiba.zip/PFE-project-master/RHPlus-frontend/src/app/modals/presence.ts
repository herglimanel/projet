export class Presence {
    id: number;
    day: any;
    nbrheures: number;
    
    
  }