export class Todo {
    id: number;
    title: string;
    description: string;
    time: Date;
    completed: boolean;
    
  }