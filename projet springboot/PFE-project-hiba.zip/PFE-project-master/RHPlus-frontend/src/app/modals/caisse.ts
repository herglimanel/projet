import { User } from './user';

export class Caisse {
    idCaisse:number;
    budget:number;
    depense:string;
    description:string;
    montant:number;
    user: User;
}