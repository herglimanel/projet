export class Candidate {
    idUser:number;
	  prenom:String;
	  nom:String;
      dateOfBirth:Date;
	  phone:String;
	  email:String;
	  cin:String;
	  adresse:String;
	  ville:String;
	  photo :String;
      password:String;
      pathCv :string;
	  pathMotivationLetter:String;
	  niveauEtud:String;
	  titreDiplome:String;
	  university:String;
	  niveauExp:String;
	  experience:String;
	  archived :Boolean; 
	
}