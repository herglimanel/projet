export class Evenement {

      id:number ; 
	
      title:String ;
      
	  description:String ; 
	
	  start:String;
	
      end:String ;
}