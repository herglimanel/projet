import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demande-doc',
  templateUrl: './demande-doc.component.html',
  styleUrls: ['./demande-doc.component.css']
})
export class DemandeDocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
