package com.HRPlus.space;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrPlusApplicationTests {

	@Test
	void contextLoads() {
	}

}
