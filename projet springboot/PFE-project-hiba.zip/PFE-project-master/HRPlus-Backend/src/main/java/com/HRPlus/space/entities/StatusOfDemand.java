package com.HRPlus.space.entities;

public enum StatusOfDemand {

	ACCEPTED , REJECTED , NOT_YET_TREATED
}
