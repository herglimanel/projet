# PFE-project
Ressource management platform built using spring boot, angular8 and postgreSQL
